<?php

namespace App\Http\Controllers;


use App\Models\Product;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function addproduct(){
        $categories = Category::All()->pluck('category_name','category_name');
        return view('admin.addproduct')->with('categories',$categories);
    }
    public function products(){
        $products = Product::All();
        return view('admin.products')->with('products',$products);
    }

    public function saveproduct(Request $request){
        $this->validate($request,['product_name'=>'required',
                                   'product_price'=>'required',
                                   'product_category'=>'required',
                                'product-image'=>'image|nullable|']);
    if($request->hasFile('product-image')){
        
        $fileNameWithExt = $request->file('product-image')->getClientOriginalName();
        $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
        $extension = $request->file('product-image')->getClientOriginalExtension();
        $fileNameToStore = $fileName.'_'.time().'.'.$extension;
        $path = $request->file('product-image')->storeAs('public/product_images',$fileNameToStore);

    }
    else{
$fileNameToStore = 'noimage.jpg';
    }

$product = new Product();
$product->product_name = $request->input('product_name');
$product->product_price = $request->input('product_price');
$product->product_category = $request->input('product_category');
$product->product_image = $fileNameToStore;
$product->status = 1;

$product->save();
return back()->with('status','produit ajouter avec succès');
    }

    public function edit_product($id){
        $product= Product::find($id);

        $categories = Category::All()->pluck('category_name','category_name');
        return view('admin.editproduct')->with('categories',$categories)->with('product',$product);
    }

    public function updateproduct(Request $request){
        $this->validate($request,['product_name'=>'required',
        'product_price'=>'required',
        'product_category'=>'required',
     'product-image'=>'image|nullable|']);

     $product = Product::find($request->input('id'));
     $product->product_name = $request->input('product_name');
     $product->product_price = $request->input('product_price');
     $product->product_category = $request->input('product_category');

     if($request->hasFile('product-image')){

        $fileNameWithExt = $request->file('product-image')->getClientOriginalName();
        $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
        $extension = $request->file('product-image')->getClientOriginalExtension();
        $fileNameToStore = $fileName.'_'.time().'.'.$extension;
        $path = $request->file('product-image')->storeAs('public/product_images',$fileNameToStore);
if($product->product_image != 'noimage.jpg'){
    
    Storage::delete('public/product_images/'.$product->product_image);
}
        $product->product_image = $fileNameToStore;
     }
     
     $product->update();
     return redirect('/products')->with('status','produit Modifier avec succès');
    }

    public function deleteproduct($id){
        $product = Product::find($id);
        if($product->product_image != 'noimage.jpg'){
    
            Storage::delete('public/product_images/'.$product->product_image);
        }
        $product->delete();
        return back()->with('status','produit Supprimer avec succès');
    }

    public function activer_product($id){
        $product = Product::find($id);
        $product->status = 1;
        $product->save();
        return back();
    }
    public function desactiver_product($id){
        $product = Product::find($id);
        $product->status = 0;
        $product->save();
        return back();
    }
    public function select_par_cat($category_name){
        $products = Product::All()->where('product_category',$category_name)->where('status',1);
$categories= Category::All();
        return view('client.shop')->with('products',$products)->with('categories',$categories);
    }


}
